Programming Assignment 2: Fixed-Outline Floorplanning
=======================================================

Files:
- Source code (src/pa2.cpp, src/structure.cpp, src/structure.h)
- Make File (Makefile)
- Executable (PA2)
- readme.txt (this file)
- Report (report.docx, report.pdf)

How to compile and run the program
----------------------------------
# To run the exacutable
  $ ./PA2 [α value] [input.block name] [input.net name] [output file name]

# To compile the exacutable form source code
  $ make

